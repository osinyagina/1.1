
DROP table if Exists cdm.top_page_by_sale_ts_bd;

CREATE TABLE cdm.top_page_by_sale_ts_bd (
	ts_timestamp timestamp NULL,
	ts_year int2 NULL,
	ts_month int2 NULL,
	ts_day int2 NULL,
	ts_hour int2 NULL,
    browser_name varchar(32),
	device_type varchar(16),
	device_is_mobile boolean, 
	page_url varchar(128) NULL,
	purchase_num int4 NULL,
	id serial4 NOT NULL,
	CONSTRAINT top_page_by_sale_ts_bd_pk PRIMARY KEY (id),
	CONSTRAINT top_page_by_sale_ts_bd_un UNIQUE (ts_timestamp, page_url)
);


DROP TABLE cdm.event_by_ts_bd;

CREATE TABLE cdm.event_by_ts_bd (
	id serial4 NOT NULL,
	ts_timestamp timestamp NULL,
	ts_year int2 NULL,
	ts_month int2 NULL,
	ts_day int2 NULL,
	ts_hour int2 NULL,
	browser_name varchar(32),
	device_type varchar(16),
	device_is_mobile boolean,
	event_num int4 NULL,
	purchase_num int4 NULL,
	CONSTRAINT event_by_ts_bd_pkey PRIMARY KEY (id),
	CONSTRAINT event_by_ts_bd_un UNIQUE (ts_timestamp, browser_name, device_type, device_is_mobile)
);


DROP TABLE cdm.utm_source_share;

CREATE TABLE cdm.utm_source_share (
	ts_timestamp timestamp NOT NULL,
	ts_year int2 NULL,
	ts_month int2 NULL,
	ts_day int2 NULL,
	ts_hour int2 NULL,
	utm_source varchar(128) NOT NULL,
	user_count int4 NULL,
	CONSTRAINT utm_source_share_pk PRIMARY KEY (ts_timestamp, utm_source)
);


drop table if exists cdm.top_page_by_sale;
create table cdm.top_page_by_sale (
	page_url varchar(128),
	purchase_num int
)

drop table if exists cdm.top_page_by_sale_ts;
create table top_page_by_sale_ts (
	ts_timestamp timestamp,
	ts_year int2,
	ts_month int2,
	ts_day int2,
	ts_hour int2,
	page_url varchar(128),  
	purchase_num int
);


drop table if exists cdm.event_by_ts;

CREATE TABLE cdm.event_by_ts (
	id serial4 NOT NULL,
	ts_timestamp timestamp NULL,
	ts_year int2 NULL,
	ts_month int2 NULL,
	ts_day int2 NULL,
	ts_hour int2 NULL,
	event_num int4 NULL,
	purchase_num int4 NULL,
	CONSTRAINT event_by_ts_pkey PRIMARY KEY (id),
	CONSTRAINT event_by_ts_un UNIQUE (ts_timestamp)
);


drop table if exists cdm.events;
CREATE TABLE cdm.events
(
    id BIGSERIAL NOT NULL PRIMARY KEY,
    date DATE NOT NULL,
    hour INT NOT NULL,
    event_num INT NOT NULL,
    purchase_num INT NOT NULL,
    UNIQUE(date, hour)
);

drop table if exists cdm.links;
CREATE table cdm.links
(
    id BIGSERIAL NOT NULL PRIMARY KEY,
    date DATE NOT NULL,
    page_url_path TEXT NOT NULL,
    purchase_num INT NOT NULL,
    UNIQUE(date, page_url_path)
);